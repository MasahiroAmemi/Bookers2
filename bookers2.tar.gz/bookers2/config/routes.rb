Rails.application.routes.draw do
  devise_for :users
  root "homes#index"
  resources :homes, only: [:new, :create, :show]
  resources :users
  resources :books
  get "/home/about" => "homes#show", as: "about"
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
